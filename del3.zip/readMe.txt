Use del3 /? to access help

www.info2000.biz